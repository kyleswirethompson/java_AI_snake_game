

// 100 MILLI SECONDS HAVE BEEN GIVEN FOR THE PLAYER TO MAKE A MOVE //


package players;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.Set;
import snake.GameState;
import snake.Snake;
import static players.RandomPlayer.rand;
import java.lang.Math; 


/**
 *
 * @author Kyle Swire-Thompson
 */
public class MinimaxPlayer extends RandomPlayer {
    Map<Position, Integer> positions;
    public MinimaxPlayer(GameState state, int index, Snake game) {
        super(state, index, game);
    }
    public void doMove() {
        initPositions();
        Node n = searchTarget();
        if (n != null) {
            state.setOrientation(index, n.getFirstMove());
        }
        else {
            System.out.println("MinimaxPlayer player doing random move");
            doRandomMove();
        }
    }

    /*
     * We want to select the move which gets us closest to the target
     */
    private Node searchTarget() {  	   
    	Node int_node = new Node(state.getPlayerX(index).get(0), state.getPlayerY(index).get(0), state.getTargetX(), state.getTargetY());
        List<Node> initial_legal_Nodes = get_legal_connected_nodes(int_node, 1);
        long timeup = System.currentTimeMillis() + 100;
        Node bestnode = null;
        double bestScore = 0;
        if (state.getTargetX() == int_node.x && state.getTargetY() == int_node.y) {
            return int_node;
        }
      	while ( System.currentTimeMillis() < timeup) {  
       		Node curr_node = new Node(state.getPlayerX(index).get(0), state.getPlayerY(index).get(0), state.getTargetX(), state.getTargetY());       		      		
	    	for (int depthLimit = 1; depthLimit< Double.POSITIVE_INFINITY ; depthLimit++) {
		       if (System.currentTimeMillis() > timeup) {		                
	                break;
		        }
	            for (Node n : initial_legal_Nodes) {         
	                double score = getMinScoreAlphaBeta(n, curr_node , depthLimit - 1, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY,timeup);
	                if (System.currentTimeMillis() > timeup) {	                		                
	                    break;
	                } 
	                if (bestnode == null || score > bestScore) {
	                    bestnode = n;
	                    bestScore = score;
	                }                                          
	            }	         
		    }  
	    }	       
        return bestnode;           
    }

   	private double getMinScoreAlphaBeta(Node n, Node previous_node, int depth, double alpha, double beta, long timeup) {
	    if (depth == 0 || state.getTargetX() == n.x && state.getTargetY() == n.y) {
	        return evaluateState(n);
	    }
	    List<Node> possible_nodes = get_legal_connected_nodes(n, depth);
	    double res = Double.POSITIVE_INFINITY;
	    double score = Double.POSITIVE_INFINITY;
	    for (Node move : possible_nodes) {                
	        if (!move.equals(previous_node)) {
	           	Double chance_score = getchancescore(move);     		
	            score = getMaxScoreAlphaBeta(move, previous_node, depth - 1, alpha, beta, timeup); 
	
	            // this updates the score so that it takes into acound the possible locations of the next targets //
	  			score= round_2dp(score + score*chance_score);	  			
	            res = Math.min(res, score);
		        beta = Math.min(beta, score);
		        if (beta <= alpha || (System.currentTimeMillis() > timeup)){
		                break;
		        }
	        }	    
	    }	     
	    return res;
	}

    private double getMaxScoreAlphaBeta(Node n, Node previous_node, int depth, double alpha, double beta, long timeup) {
	   if (depth == 0 || state.getTargetX() == n.x && state.getTargetY() == n.y) {
	    	return evaluateState(n);
	    }
	    List<Node> possible_nodes = get_legal_connected_nodes(n, depth);
	    double res = Double.NEGATIVE_INFINITY;
	    double score = Double.NEGATIVE_INFINITY;

	    for (Node move : possible_nodes) {              
	        if (!move.equals(previous_node)) {
	        	double chance_score = getchancescore(move);
	            score =getMinScoreAlphaBeta(move, previous_node, depth - 1, alpha, beta, timeup);

	            // this updates the score so that it takes into acound the possible locations of the next targets //
	  			score= round_2dp(score + score*chance_score);
	       		res = Math.max(res, score);
	        	alpha = Math.max(alpha, score);
	        	if (beta <= alpha || (System.currentTimeMillis() > timeup)){
	                break;
	        	}          	                                 
	        }
	    }
	    return res;
	}
	// this function will round to 2 decimal places //
    public double round_2dp(double a ){
    	a = Math.round(a * 100.0) / 100.0;
    	return a;
    }
    // this funtion will return the average distance of 5 randomly chossen legal nodes for the next targt to be, in the range of 0<x<1
    public double getchancescore(Node n){    	   	
        List<Node> possible_locations_of_disk = new ArrayList<Node>();
        boolean first_pass = true;	          	
    	for (int i =0 ; i < 4; i++) {
    		Node ran_dot_pos = get_random_dot_position(n);
    		if (i == 0 ) {
    			possible_locations_of_disk.add(ran_dot_pos);
    			first_pass = false;
    		}
    		if (first_pass == false && !ran_dot_pos.equals(possible_locations_of_disk.get(i))) {    			
    			possible_locations_of_disk.add(ran_dot_pos);
    		}    		  		
    	}  
	    double sum_of_distance = 0;
	    for (int i =0 ; i < possible_locations_of_disk.size()-1; i++) {
	    	sum_of_distance = sum_of_distance + get_distance(state.getPlayerX(index).get(0), state.getPlayerY(index).get(0),possible_locations_of_disk.get(i));
	    }	    
	    double average_distance = sum_of_distance/5;    
		double max_possible_dis_to_travel = state.getWidth() + state.getHeight();
		double chance_score = round_2dp((max_possible_dis_to_travel-average_distance)/max_possible_dis_to_travel);		
		return chance_score;	    
    }
    // this gets the distance between an x and y point against a given node //
    public double get_distance(int x1, int y1, Node n){
    	int distance_x = Math.abs(n.x - x1);
    	int distance_y = Math.abs(n.y - y1);
    	int total_distance = distance_x + distance_y;
    	return total_distance;
    } 
    // this returns the legal nodes connected to the node that has been passed // 
    private  List<Node> get_legal_connected_nodes(Node n , int depth){
        List<Node> nodes = new ArrayList<Node>();
        if (!isOccupied(n.x + 1, n.y, depth)) {
            nodes.add(new Node(n.x + 1, n.y, n));
        }
        if (!isOccupied(n.x - 1, n.y, depth)) {
            nodes.add(new Node(n.x - 1, n.y, n));
        }
        if (!isOccupied(n.x, n.y + 1, depth)) {
            nodes.add(new Node(n.x, n.y + 1, n));
        }
        if (!isOccupied(n.x, n.y - 1, depth)) {
            nodes.add(new Node(n.x, n.y - 1, n));
        }
    	return nodes;
    }
    // this evaluates the given node using the distance away from the target//
    public double evaluateState(Node n) {
	    Node node_to_evaluate = n;
	    int diff_y = Math.abs(state.getTargetY() - n.y);
	    int diff_x = Math.abs(state.getTargetX() - n.x);
	    double score =  (diff_y + diff_x);
	    return -score;
    }
    // this will produce a randomly sellected legal node //
    public Node get_random_dot_position(Node n) {
        int dot_X = rand.nextInt(state.getWidth());
        int dot_Y = rand.nextInt(state.getWidth());
        while (state.isOccupied(dot_X,dot_Y)) {
            dot_X = rand.nextInt(state.getWidth());
            dot_Y = rand.nextInt(state.getWidth());
        }
        // this will not allow a dot to be chossen if it is too close to another player which would give them an advantage and skew the results\\
        if (!isOccupied(dot_X, dot_Y, 3)) {
            Node ran_dot_pos = new Node(dot_X, dot_Y, n);
            return ran_dot_pos;           
    	}
    	Node ran_dot_pos = get_random_dot_position(n);
    	return ran_dot_pos; 
    }
    private void initPositions() {
        positions = new HashMap();
        for (int i = 0; i < state.getNrPlayers(); i++) {
            if (!state.isDead(i)) {
                List<Integer> xList = state.getPlayerX(i);
                List<Integer> yList = state.getPlayerY(i);
                for (int j = 0; j < xList.size(); j++) {
                    positions.put(new Position(xList.get(j), yList.get(j)), xList.size() - j);
                }
            }
        }
    }

    private boolean isOccupied(int x, int y, int step) {
        if (x < 0 || x >= state.getWidth() || y < 0 || y >= state.getHeight()) {
            return true;
        }
        else if (!state.isOccupied(x, y)) {
            return false;
        }
        int cutoff = positions.get(new Position(x, y));
        return step <= cutoff;
    }
}
